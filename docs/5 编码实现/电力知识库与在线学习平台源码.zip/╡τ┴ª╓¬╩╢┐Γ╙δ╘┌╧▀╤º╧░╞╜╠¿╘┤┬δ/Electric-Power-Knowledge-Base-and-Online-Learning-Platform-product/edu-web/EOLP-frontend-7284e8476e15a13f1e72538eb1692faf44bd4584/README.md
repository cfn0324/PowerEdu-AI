# 环境

node 18.15

# 安装依赖

```shell
npm i
```

# 启动

```shell
npm run dev
```
