# 看这里

edu 是 Django 后端 python3.8

edu-web 是 React 前端 node 18.15

查看各下面的`README.md` 启动
